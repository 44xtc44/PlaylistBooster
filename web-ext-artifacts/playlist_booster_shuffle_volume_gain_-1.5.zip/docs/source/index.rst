Welcome to Playlist Booster's documentation!
============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   README
   modules
